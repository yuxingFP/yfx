from po.page import Page
from selenium.webdriver.common.by import By
class Custom_model(Page):
    # 自定义分析模型管理
    menu = (By.XPATH, "//span[text()='自定义分析模型管理']")
    new_add = (By.XPATH,"//span[text()='新增']")