# a = ",ddd:122,dsdd:124"
# a = a[1:-1]
#
# print(a)
# for i in range(1,5):
#     print(i)
str = "aerfer"
str_1 = "234"
print(str+str_1)